//
//  ViewController.swift
//  ASN3
//
//  Created by CompSci 4220 Student on 7/1/21.
//

import UIKit

class ViewController: UIViewController {
    //notsure the proper way to remove this
    @IBOutlet weak var GreenView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

